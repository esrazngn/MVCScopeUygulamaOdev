package com.ykb.web;

import java.io.*;

public class IsimBean implements Serializable {
	private String isim = "�sim Eksik";
	private String soyisim = "Soyisim Eksik";

	public String getIsim() {
		return (isim);
	}

	public void setIsim(String isim) {
		if (!isMissing(isim)) {
			this.isim = isim;
		}
	}

	public String getSoyisim() {
		return (soyisim);
	}

	public void setSoyisim(String soyisim) {
		if (!isMissing(soyisim)) {
			this.soyisim = soyisim;
		}
	}

	private boolean isMissing(String value) {
		return ((value == null) || (value.trim().equals("")));
	}
}
