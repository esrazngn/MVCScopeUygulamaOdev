package com.ykb.web;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@WebServlet("/register")
public class KayitServlet extends HttpServlet {
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
		
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		synchronized (session) {
			IsimBean isimBean = (IsimBean) session.getAttribute("isim");
			if (isimBean == null) {
				isimBean = new IsimBean();
				session.setAttribute("isim", isimBean);
			}
			isimBean.setIsim(request.getParameter("isim"));
			isimBean.setSoyisim(request.getParameter("soyisim"));
			String address = "/WEB-INF/results/show-name.jsp";
			RequestDispatcher dispatcher = request
					.getRequestDispatcher(address);
			dispatcher.forward(request, response);
		}
	}
}
