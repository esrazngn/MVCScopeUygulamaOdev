package com.ykb.web;

import java.util.*;

public class MusteriMap implements MusteriAramaServisi {
	private Map<String, Musteri> musteris;

	public MusteriMap() {
		musteris = new HashMap<String, Musteri>();
		addMusteri(new Musteri("admin", "Esra", "Zengin", 3456.78));
		addMusteri(new Musteri("id1", "S�meyye", "Kaptan", -1234.56));
		addMusteri(new Musteri("id2", "Ali", "Can", 987654.32));
	}

	public Musteri findMusteri(String id) {
		if (id != null) {
			return (musteris.get(id.toLowerCase()));
		} else {
			return (null);
		}
	}

	private void addMusteri(Musteri musteri) {
		musteris.put(musteri.getId(), musteri);

	}
}
