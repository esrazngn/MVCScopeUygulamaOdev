package com.ykb.web;


public class NumaraBean {
  private final double num;

  public NumaraBean(double number) {
    this.num = number;
  }
  
  public double getNumber() {
    return(num);
  }
}
