package com.ykb.web;

import java.math.BigInteger;

public class AsalBean {
	private BigInteger asal;

	public AsalBean(String lengthString) {
		int length = 150;
		try {
			length = Integer.parseInt(lengthString);
		} catch (NumberFormatException nfe) {
		}
		this.asal = Primes.nextPrime(Primes.random(length));
	}

	public BigInteger getAsal() {
		return (asal);
	}
}
