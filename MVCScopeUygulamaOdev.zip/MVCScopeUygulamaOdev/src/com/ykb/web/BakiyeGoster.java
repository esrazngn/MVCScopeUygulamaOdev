package com.ykb.web;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@WebServlet("/show-balance")
public class BakiyeGoster extends HttpServlet {
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String musteriId = request.getParameter("musteriId");
		MusteriAramaServisi service = new MusteriMap();
		Musteri musteri = service.findMusteri(musteriId);
		request.setAttribute("musteri", musteri);
		String address;
		if (musteri == null) {
			request.setAttribute("musteriId", musteriId);
			address = "/WEB-INF/results/unknown-customer.jsp";
		} else if (musteri.getBakiye() < 0) {
			address = "/WEB-INF/results/negative-balance.jsp";
		} else if (musteri.getBakiye() < 10000) {
			address = "/WEB-INF/results/normal-balance.jsp";
		} else {
			address = "/WEB-INF/results/high-balance.jsp";
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(address);
		dispatcher.forward(request, response);
	}
}
