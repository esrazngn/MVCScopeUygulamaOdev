package com.ykb.web;

public class Musteri {
  private final String id, isim, soyisim;
  private final double bakiye;

  public Musteri(String id,
                  String isim,
                  String soyisim,
                  double bakiye) {
    this.id = id;
    this.isim = isim;
    this.soyisim = soyisim;
    this.bakiye = bakiye;
  }
  
  public String getId() {
    return id;
  }

  public String getIsim() {
    return(isim);
  }

  public String getSoyisim() {
    return(soyisim);
  }

  public double getBakiye() {
    return(bakiye);
  }

  public String getBakiyeNoSign() {
    String bakiyeString = 
      String.format("%,.2f", Math.abs(bakiye));
    return(bakiyeString);
  }
}
  
