package com.ykb.web;

public class RanUtils {
	public static NumaraBean randomNum(String rangeString) {
		double range;
		try {
			range = Double.parseDouble(rangeString);
		} catch (Exception e) {
			range = 10.0;
		}
		return (new NumaraBean(Math.random() * range));
	}

	private RanUtils() {
	}
}
