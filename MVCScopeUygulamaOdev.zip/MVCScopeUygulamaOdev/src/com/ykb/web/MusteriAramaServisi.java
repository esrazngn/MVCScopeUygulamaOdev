package com.ykb.web;

public interface MusteriAramaServisi {
  public Musteri findMusteri(String id);
}
