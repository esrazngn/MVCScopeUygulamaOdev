package com.ykb.web;  

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;


@WebServlet("/find-prime")
public class AsalServlet extends HttpServlet {
  @Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
    }
		
		public void doPost(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			String length = request.getParameter("primeLength");
			ServletContext context = getServletContext();
			synchronized (this) {
				if ((context.getAttribute("primeBean") == null)
						|| (!isMissing(length))) {
					AsalBean primeBean = new AsalBean(length);
					context.setAttribute("primeBean", primeBean);
				}
	 String address = "/WEB-INF/results/show-prime.jsp";
	      RequestDispatcher dispatcher =
	        request.getRequestDispatcher(address);
	      dispatcher.forward(request, response);
	    }
  }
  
  private boolean isMissing(String primeLength) {
    return((primeLength == null) || 
           (primeLength.trim().equals("")));
  }
}
